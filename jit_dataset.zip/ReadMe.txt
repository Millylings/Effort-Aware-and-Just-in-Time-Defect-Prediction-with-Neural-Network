#Running R scripts#
INPUT: data from the "input" folder
OUTPUT: stored in the "output" folder

working directory is "script_r" folder. This "script_r" folder consists of R scripts and README.txt that explains how to run R scripts.

We have two main R scripts which evaluate the prediction performance for RQ1 and RQ2 (exeExperimentPred.r) and evaluate the impact of change factors on defect-inducing changes for RQ3 (exeExperimentFactor.r). These scripts read in the data from the input folder and output to screen,in R and the "output" folder.
